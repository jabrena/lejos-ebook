import lejos.nxt.*;
import java.io.*;

/**
 * @author juanantonio.bre�a
 *
 */
public class BatteryThread extends Thread{

	//Exchange Data Object
	private LRDataBridge db;

	private int battery = 0;
	private int memory = 0;

	public BatteryThread(LRDataBridge d){
		
		db = d;
	}
	
	public void run(){
		while(true){
			
			battery = Battery.getVoltageMilliVolt();
			db.setBattery(battery);
			memory = File.freeMemory();
			db.setMemory(memory);
		}
	}
}
