import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Vector;

import javax.bluetooth.RemoteDevice;
import javax.microedition.location.Coordinates;

//import lejos.gps.GPS;
import lejos.nxt.comm.*;
import lejos.nxt.*;
import lejos.util.Stopwatch;

/**
 * 
 * @author Juan Antonio Brenha Moral
 *
 */
public class GPSThread extends Thread{
	//GPS Receiver
	private String GPSPattern = "";
	static private byte[] pin = {};

	//Inquire code
	private static byte[] cod = {0,0,0,0}; // 0,0,0,0 picks up every Bluetooth device regardless of Class of Device (cod).
	
	//Bluetooth Connection messages
	private String MESSAGE_SEARCHING = "Searching";
	private String MESSAGE_CONNECTING = "Connecting";
	private String MESSAGE_CONNECTED = "Connected";
	private String MESSAGE_RECONNECTING = "Reconnecting";
	private String MESSAGE_CONNECTION_FAILED = "Connection failed";
	private String MESSAGE_NO_GPS = "No detected GPS";
	
	private String MESSAGE_CLOSING = "Closing...";

	//Bluetooth
	static private RemoteDevice GPSDevice = null;
	static private BTConnection btGPS = null;
	static private InputStream in = null;
	static protected GPS gps = null;

	//Detect GPS Device
	private boolean GPSDetected = false;
	//Connect with GPS Device
	private int connectionStatus = 0;
	
	//GPS Data
	private Date init;
	private Date now;
	protected Coordinates origin;
	protected Coordinates current;

	//Command to process
	private int CMD = 0;
	
	//Connection counter
	private int connectionCounter = 0;
	
	//Exchange Data Object
	private LRDataBridge db;
	
	//LCD
	private int LCDRow = 6;

	/* CONSTRUCTOR */
	
	public GPSThread(String gpsp, byte[] p){
		GPSPattern = gpsp;
		pin = p;
	}

	public GPSThread(String gpsp, byte[] p, LRDataBridge dObj){
		GPSPattern = gpsp;
		pin = p;
		
		db = dObj;
	}

	/* Setters & Getters */

	public void setCommand(int c){
		CMD = c;
	}

	public void run(){
		
		while(true){
			if(CMD == 1){
				//fetchData();
				CMD = 0;
			}else if(CMD == 2){
				readGPS();
			}
		}
	}

	/**
	 * Methods used to discover a predefined GPS receiver and you need
	 * to connect with it directly.
	 * 
	 * @param BTPatternName
	 * @return
	 */
	private boolean discoverBTDevice(String BTPatternName){
		boolean GPSDetected = false;
		RemoteDevice btrd = null;
		String BTDeviceName;

		//LCD.drawString(MESSAGE_SEARCHING, 0, LCDRow);
		//LCD.refresh();
		db.setBTGPSMSG(MESSAGE_SEARCHING);
		Vector devList = Bluetooth.getKnownDevicesList();

		if(devList.size() > 0){
			for (int i = 0; i < devList.size(); i++) {
				btrd = ((RemoteDevice) devList.elementAt(i));

				BTDeviceName = btrd.getFriendlyName(true);
				if(BTDeviceName.indexOf(BTPatternName) != -1){
					GPSDevice = btrd;
					GPSDetected = true;
					break;
				}
				
			}
		}

		return GPSDetected;
	}

	static boolean discoverBTDevices(){
		boolean GPSDetected = false;
		
		LCD.clear();
		LCD.drawString("Searching...", 0, 0);
		LCD.refresh();
		//Make an BT inquire to get all Devices with BT Services enable
		Vector devList = Bluetooth.inquire(5, 10,cod);

		//If exist GPS Devices near
		if (devList.size() > 0){
			String[] names = new String[devList.size()];
			for (int i = 0; i < devList.size(); i++) {
				RemoteDevice btrd = ((RemoteDevice) devList.elementAt(i));
				names[i] = btrd.getFriendlyName(true);
			}
				
			TextMenu searchMenu = new TextMenu(names,1);
			String[] subItems = {"Connect"};
			TextMenu subMenu = new TextMenu(subItems,4);
			
			int selected;
			do {
				LCD.clear();
				LCD.drawString("Found",6,0);
				LCD.refresh();
				//Menu 1: Show all BT Devices
				selected = searchMenu.select();
				if (selected >=0){
					RemoteDevice btrd = ((RemoteDevice) devList.elementAt(selected));
					LCD.clear();
					LCD.drawString("Found",6,0);
					LCD.drawString(names[selected],0,1);
					LCD.drawString(btrd.getBluetoothAddress(), 0, 2);
					//Menu 2: Show GPS Device
					int subSelection = subMenu.select();
					if (subSelection == 0){
						GPSDetected = true;
						GPSDevice = btrd;
						break;
					}
				}
			} while (selected >= 0);
		}else{
			GPSDetected = false;
		}

		return GPSDetected;
	}
	
	/**
	 * This method connect with a RemoteDevice.
	 * If the connection has success then the method create an instance of
	 * the class GPS which manages an InputStream
	 * 
	 * @return
	 */
	static int connectGPS(){
		int result;
		//Bluetooth.addDevice(GPSDevice);

		//BTConnection btGPS = null;
		btGPS = Bluetooth.connect(GPSDevice.getDeviceAddr(), NXTConnection.RAW,pin);
		
		if(btGPS == null){
			result  = -1;//No connection
		}else{
			result = 1;//Connection Sucessful
		}

		try{
			in = btGPS.openInputStream();
			gps = new GPS(in);
			gps.updateValues(true);//Update values always

			result = 2;//
		}catch(Exception e){
			result = -2;
		}
		
		return result;
	}

	private void readGPS(){
		//Store the initial coordinate and the moment
		boolean firstMomentFlag = false;
		
		while(true){
			//1. Detect
			//GPSDetected = discoverBTDevice(GPSPattern);
			GPSDetected = discoverBTDevices();
			if(GPSDetected){
				//2. Connecting
				//LCD.drawString(MESSAGE_CONNECTING, 0, LCDRow);
				//LCD.refresh();
				db.setBTGPSMSG(MESSAGE_CONNECTING);
				connectionStatus = connectGPS();
	
				if(connectionStatus == 2){
					db.setGPSEnabled(true);
					//LCD.drawString(MESSAGE_CONNECTED, 0, LCDRow);
					//LCD.refresh();
					db.setBTGPSMSG(MESSAGE_CONNECTED);
					Sound.beep();
					
					Stopwatch sw = new Stopwatch();
					
					//While exist a BT Connection (GPS Object process InputStream)
					while(!gps.existInternalError()){

						//Beep system
						/*
						if(sw.elapsed() >= 10000){
							sw.reset();
							Sound.beep();
						}
						*/

						//This block store origin GPS Data and Time
						if(!firstMomentFlag){
							//A way to isolate date object from init to current
							Date tempDate = gps.getDate();
							int hours = tempDate.getHours();
							int minutes = tempDate.getMinutes();
							int seconds = tempDate.getSeconds();
							int year = tempDate.getYear();
							int month = tempDate.getMonth();
							int day = tempDate.getDay();
							init = new Date();
							init.setHours(hours);
							init.setMinutes(minutes);
							init.setSeconds(seconds);
							init.setYear(year - 2000);
							init.setMonth(month);
							init.setDay(day);
							
							origin = new Coordinates(gps.getLatitude(),gps.getLongitude(),gps.getAltitude());
							
							//Repeat the operation until you have valid data:
							if(
								(init.getSeconds() != 0) && 
								(gps.getLatitude() != 0) &&
								(gps.getGPSStatus())
								){

								db.setOrigin(origin);
								db.setInit(init);

								firstMomentFlag = true;
							}
						}
						current = new Coordinates(gps.getLatitude(),gps.getLongitude(),gps.getAltitude());
						db.setCurrent(current);
						db.setNow(gps.getDate());
						db.setSatellitesTracked(gps.getSatellitesTracked());
						db.setGPSSpeed(gps.getSpeed());
					}
					//LCD.drawString(MESSAGE_RECONNECTING, 0, LCDRow);
					//LCD.refresh();
					db.setBTGPSMSG(MESSAGE_RECONNECTING);
					db.setGPSEnabled(false);
				}else{
					//LCD.drawString(MESSAGE_CONNECTION_FAILED, 0, LCDRow);
					//LCD.refresh();
					db.setBTGPSMSG(MESSAGE_CONNECTION_FAILED);
					db.setGPSEnabled(false);
				}
			}else{
				//LCD.drawString(MESSAGE_NO_GPS, 0, LCDRow);
				//LCD.refresh();
				db.setBTGPSMSG(MESSAGE_NO_GPS);
				db.setGPSEnabled(false);
			}
		}
	}

	
	//CMD1: FetchData: Connect, GetGPSData, Disconnect
	/*
	private void fetchData(){
		//1. Connect
		Sound.beep();
		RemoteDevice btrd = null;
		String BTDeviceName;

		Vector devList = Bluetooth.getKnownDevicesList();

		if(devList.size() > 0){
			for (int i = 0; i < devList.size(); i++) {
				btrd = ((RemoteDevice) devList.elementAt(i));

				BTDeviceName = btrd.getFriendlyName(true);
				if(BTDeviceName.indexOf(GPSPattern) != -1){
					//GPSDevice = btrd;
					GPSDetected = true;
					break;
				}
				
			}
		}

		if(GPSDetected){
			int result;

			BTConnection btGPS = null;
			btGPS = Bluetooth.connect(btrd.getDeviceAddr(), NXTConnection.RAW,pin);
			
			if(btGPS == null){
				result  = -1;//No connection
			}else{
				result = 1;//Connection Sucessful
			}

			try{
				in = btGPS.openInputStream();
				gps = new GPS(in);

				result = 2;//
				Sound.beep();
			}catch(Exception e) {
				result = -2;
			}

			boolean flag = true;
			Stopwatch sw = new Stopwatch();
			
			gps.updateValues(true);
			
			boolean firstMomentFlag = false;
			
			while(flag){
				if(sw.elapsed() >= 10000){
					sw.reset();
					//Sound.buff();
					
					//Finish the loop
					flag = false;
				}

				current = new Coordinates(gps.getLatitude(),gps.getLongitude(),gps.getAltitude());
				LCD.drawString("d" + gps.getLatitude(), 0, 0);
				LCD.refresh();
				db.setCurrent(current);
			}
			
			gps.updateValues(false);
			Sound.beep();
			
			//Close connections
		}
	}
	*/
}
