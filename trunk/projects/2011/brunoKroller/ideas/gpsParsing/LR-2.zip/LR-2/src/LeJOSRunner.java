import lejos.nxt.*;


/**
 * @author Juan Antonio Brenha Moral
 *
 */
public class LeJOSRunner {
	//GPS Receiver
	static private String GPSName = "HOLUX GPSlim240";
	static private byte[] pinCode = {(byte) '0', (byte) '0', (byte) '0', (byte) '0'};//GPS Pin
	
	//Exchange Data Object
	private static LRDataBridge TLBDB;
	private static GPSThread gt;
	private static WaypointRecorder WR;
	private static LRGUI gObj;

	//	NMEA 0183(V3.01) GGA,GSA,GSV,RMC,VTG
	public static void main(String[] args){
		try{
			TLBDB = new LRDataBridge();
			BatteryThread bt = new BatteryThread(TLBDB);
			GPSThread gt = new GPSThread(GPSName,pinCode,TLBDB);
			WR = new WaypointRecorder(TLBDB);
			gObj = new LRGUI(TLBDB);

			bt.start();
			gt.start();
			gt.setCommand(2);
			WR.start();
			gObj.start();
		}catch(Exception e){
			LCD.drawString("Problem starting",0,0);
			LCD.refresh();
		}

		while(!Button.ESCAPE.isPressed()){

		}

		try{
			WR.close();
		}catch(Exception e){
			LCD.drawString("Problem finishing",0,1);
			LCD.refresh();
		}
		System.exit(0);
	}
}
