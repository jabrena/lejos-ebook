import java.util.Random;

import javax.microedition.location.Coordinates;

import lejos.nxt.LCD;
import lejos.nxt.Sound;
import lejos.util.Stopwatch;
import java.util.Date;

/**
 * 
 */

/**
 * @author juanantonio.bre�a
 *
 */
public class WaypointRecorder extends Thread{

	//Exchange Data Object
	private LRDataBridge db;
	private Stopwatch sw;

	private final String CRLF = "\r\n";
	private String name = "LeJOS Runner";
	private String description = "This file store KML Points stored in a leJOS Runner session";
	private String folderName = "LeJOS Runner Placemarks";
	private String folderDescription = "Placemarks generated in a working session";

	private KML k;

	private FileManager3 fm;
	private String text  = "";
	
	private Coordinates current;
	
	int seconds = 1000;
	int delay = 30 * seconds;//Every 60 secons (1 Minute), the system store a waypoint;

	int i = 0;
	
	public WaypointRecorder(LRDataBridge dObj){
		db = dObj;
		
		sw = new Stopwatch();
		k = new KML(name,description,folderName,folderDescription);

		String fileName ="lrw.kml";
		Random r = new Random();
		fileName = "lrw_" + r.nextInt(1000) + ".kml";
		fm = new FileManager3(fileName);
		fm.delete();

		text = k.getKMLHeader();
		fm.open();
		fm.add(text);
		fm.close();
	}
	
	public void run(){
		
		StringBuffer pDescription;
		Date now;
		
		
		
		while(true){

			if(sw.elapsed() >= delay){
				if(db.getGPSEnabled()){
					i++;
					db.setWaypointCounter(i);
					
					current = db.getCurrent();
					
					now = db.getNow();

					pDescription = new StringBuffer();
					pDescription.append(CRLF + "<![CDATA[" + CRLF);
					pDescription.append("<battery>");
					pDescription.append("" + db.getBattery());
					pDescription.append("</battery>" + CRLF);
					pDescription.append("<memory>");
					pDescription.append("" + db.getMemory());
					pDescription.append("</memory>" + CRLF);
					pDescription.append("<satellites>");
					pDescription.append("" + db.getSatellitesTracked());
					pDescription.append("</satellites>" + CRLF);
					pDescription.append("<time>");
					pDescription.append("" + now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds());
					pDescription.append("</time>" + CRLF);
					pDescription.append("<speed>");
					pDescription.append("" + db.getGPSSpeed());
					pDescription.append("</speed>" + CRLF);
					pDescription.append("]]>" + CRLF);
					

					
					Placemark p = new Placemark("waypoint"+i,pDescription.toString(),current.getLatitude(),current.getLongitude(),current.getAltitude());
					text = p.toString();
					fm.open();
					fm.add(text);
					fm.close();
				}

				sw.reset();

			}
		}
	}
	
	public void close(){
		fm.open();
		text = k.getKMLFooter();
		fm.add(text);
		fm.close();
	}
}
