import javax.microedition.location.Coordinates;
import java.util.Date;
import lejos.nxt.LCD;


/**
 * @author juanantonio.bre�a
 *
 */
public class LRGUI extends Thread{

	//GPS Data
	private Date init;
	private Date now;
	private Coordinates previous;
	private Coordinates current;
	double distance = 0;
	double accumulativeDistance = 0;
	boolean firstTime = false;
	private String gpsStatus = "";
	
	
	//Exchange Data Object
	private LRDataBridge db;
	
	public LRGUI(LRDataBridge dObj){
		db = dObj;
	}
	
	public void run(){
		
		while(true){
			LCD.drawString("LeJOS Runner",0,0);
			
			if(db.getGPSEnabled()){
				if(!firstTime){
					previous = db.getCurrent();
				}
				current = db.getCurrent();

				init = db.getInit();
				now = db.getNow();
	
				clearSomeRows();
				LCD.drawString("Date:  " + now.getYear() + "/" + now.getMonth() + "/" + now.getDay(),0,1);
				LCD.drawString("Start: " + init.getHours() + ":" + init.getMinutes() + ":" + init.getSeconds(),0,2);
				LCD.drawString("Now:   " + now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds(),0,3);
				LCD.drawString("Waypoints:  " + db.getWaypointCounter(),0,4);
				LCD.drawString("Satellites: " + db.getSatellitesTracked(),0,5);
				
				distance = current.distance(previous);

				if(!firstTime){
					firstTime = true;
				}else{
					//Avoid error when you are in the same position
					if((distance > 0.1) && (distance <= 500)){
						accumulativeDistance += distance;
					}
				}

				LCD.drawString("Distance: " + accumulativeDistance,0,6);
				
				previous = current;
			}else{
				//clearSomeRows();
			}

			gpsStatus = db.getBTGPSMSG();
			LCD.drawString("                         ",0,7);
			LCD.drawString("GPS: " + gpsStatus,0,7);
			LCD.refresh();
	
			try {Thread.sleep(500);} catch (Exception e) {}
		}
	}
	
	private void clearSomeRows(){
		LCD.drawString("                     ",0,1);
		LCD.drawString("                     ",0,2);
		LCD.drawString("                     ",0,3);
		LCD.drawString("                     ",0,4);
		LCD.drawString("                     ",0,5);
		LCD.drawString("                     ",0,6);
	}
}
