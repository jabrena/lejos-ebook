import javax.microedition.location.Coordinates;
import java.util.Date;

/**
 * This class has been designed to exchange data between the threads.
 * 
 * 
 * @author Juan Antonio Bre�a Moral
 *
 */
public class LRDataBridge {

	//GPS Thread
	private boolean GPSEnabled = false;
	private String BT_GPS_MSG = "";
	private int compassDegrees;
	private double latitude = 0;
	private double longitude = 0;
	private double altitude = 0;
	private Coordinates origin = new Coordinates(0,0,0);
	private Coordinates current = new Coordinates(0,0,0);
	private Date init = new Date();
	private Date now = new Date();
	private boolean gpsInternalProblem = false;
	private int satellitesTracked = 0;
	private float gpsSpeed = 0;

	//Waypoint Recorder Thread
	private int waypointCounter = 0;

	//System
	private int battery = 0;
	private int memory = 0;
	
	/**
	 * Constructor
	 */
	public LRDataBridge(){
		
	}


	/* GPS Methods */

	public void setBTGPSMSG(String MSG){
		BT_GPS_MSG = MSG;
	}
	
	public String getBTGPSMSG(){
		return BT_GPS_MSG;
	}

	public void setInit(Date d){
		init = d;
	}

	public Date getInit(){
		return init;
	}

	public void setNow(Date d){
		now = d;
	}

	public Date getNow(){
		return now;
	}
	
	public void setSatellitesTracked(int st){
		satellitesTracked = st;
	}
	
	public int getSatellitesTracked(){
		return satellitesTracked;
	}
	
	public void setOrigin(Coordinates o){
		origin = o;
	}
	
	public Coordinates getOrigin(){
		return origin;
	}

	public void setCurrent(Coordinates o){
		current = o;
	}
	
	public Coordinates getCurrent(){
		return current;
	}

	public void setCompassDegrees(int cd){
		compassDegrees = cd;
	}
	
	public int getCompassDegrees(){
		return compassDegrees;
	}
	
	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setAltitude(double altitude) {
		this.altitude = altitude;
	}

	public double getAltitude() {
		return altitude;
	}
	
	public void setGPSInternalStatus(boolean status){
		gpsInternalProblem = status;
	}
	
	public boolean getGPSStatus(){
		return gpsInternalProblem;
	}
	
	public boolean getGPSEnabled(){
		return GPSEnabled;
	}
	
	public void setGPSEnabled(boolean status){
		GPSEnabled = status;
	}

	public void setGPSSpeed(float speed){
		gpsSpeed = speed;
	}
	
	public float getGPSSpeed(){
		return gpsSpeed;
	}
	
	/* Waypoint Recorder */
	
	public void setWaypointCounter(int counter){
		waypointCounter = counter;
	}
	
	public int getWaypointCounter(){
		return waypointCounter;
	}

	/* System */
	
	public void setBattery(int b){
		battery = b;
	}
	
	public int getBattery(){
		return battery;
	}

	public void setMemory(int m){
		memory = m;
	}
	
	public int getMemory(){
		return memory;
	}
}
