package org.esmeralda.lejos.model;

import lejos.nxt.Battery;
import lejos.nxt.LightSensor;
import lejos.nxt.Motor;
import lejos.nxt.SensorPort;
import lejos.nxt.addon.CompassSensor;
import lejos.nxt.addon.TiltSensor;
import lejos.nxt.remote.RemoteMotor;
import lejos.robotics.navigation.TachoPilot;

/**
 * This class has beend designed to manage a physical robot 
 * @author jabrena
 *
 */
public class Robot {

	//Sensors
	private CompassSensor compass;
	private TiltSensor gyro;
	private int batteryLevel;
	
	//Actuators
    private RemoteMotor leftMotor;
    private RemoteMotor rightMotor;
    private TachoPilot pilot;
    private float wheelDiameter = 0.0f;
    private float trackWidth = 0.0f;
    private final int countsPerRevolution = 360;
    
    public Robot(float _wheelDiameter, float _trackWidth){
    	
    	//Definining sensors in the model
    	compass = new CompassSensor(SensorPort.S1);
    	gyro = new TiltSensor(SensorPort.S2);
    	batteryLevel = Battery.getVoltageMilliVolt();
    	
    	//Defining actuators in the model
		leftMotor = Motor.A;
		rightMotor = Motor.C;
		
	    leftMotor.resetTachoCount();
	    rightMotor.resetTachoCount();
    	
        wheelDiameter = _wheelDiameter;
        trackWidth = _trackWidth;
        
	    pilot = new TachoPilot(
	    		wheelDiameter, 
	    		trackWidth, 
	    		leftMotor, 
	    		rightMotor, 
	    		false);
	    
    }
    
    public TachoPilot getPilot(){
    	return pilot;
    }
    
    public RemoteMotor getLeftMotor(){
    	return leftMotor;
    }
    
    public RemoteMotor getRightMotor(){
    	return rightMotor;
    }
    
    public CompassSensor getCompass(){
    	return compass;
    }
    
    public TiltSensor getGyroSensor(){
    	return gyro;
    }

    public int getBatteryLevel(){
    	return batteryLevel;
    }
}
