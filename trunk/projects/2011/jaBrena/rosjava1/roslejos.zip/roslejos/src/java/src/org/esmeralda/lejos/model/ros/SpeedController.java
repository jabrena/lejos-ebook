package org.esmeralda.lejos.model.ros;




public class SpeedController
{
//private:
        private float _PParam, _IParam, _DParam;
        private float _CommandTimeout;
        private long _MillisecsLastCommand;
        OdometricLocalizer _pOdometricLocalizer;

        private RobotParams _pRobotParams;
        private TimeInfo _pTimeInfo;

        //float _LastLeftError, _LastRightError, _LastTurnError;
        private float _LeftErrorIntegral, _RightErrorIntegral, _TurnErrorIntegral;
        
        private float _MaxVelocityErrorIntegral;
        private float _MaxTurnErrorIntegral;

        private float ClipIntegralContribution(float integralContribution)
        {
                if (integralContribution > 1.0)
                {
                        return 1.0f;
                }
                else if (integralContribution < -1.0)
                {
                        return -1.0f;
                //buggy
                }else{
                	System.out.println("BUG");
                	return 0;
                }
        }
        
        private void Reset()
        {
                //_LastLeftError = 0.0;
                //_LastRightError = 0.0;
                _LeftErrorIntegral = 0.0f;
                _RightErrorIntegral = 0.0f;
                _TurnErrorIntegral = 0.0f;
                LeftError = 0.0f;
                RightError = 0.0f;       
                TurnError = 0.0f;        
                NormalizedLeftCV = 0.0f;
                NormalizedRightCV = 0.0f;

                CommandedVelocity = 0.0f;
                CommandedAngularVelocity = 0.0f;
        }
        
//public:
        public boolean IsInitialized;

        float VelocityPParam;
        float VelocityIParam;
        //float VelocityDParam;

        float TurnPParam;
        float TurnIParam;

        float CommandedVelocity;
        float CommandedAngularVelocity;

        float LeftError;
        float RightError;
        float TurnError;

        // normalized control values for the left and right motor
        float NormalizedLeftCV;
        float NormalizedRightCV;

        public SpeedController(OdometricLocalizer pOdometricLocalizer, RobotParams pRobotParams, TimeInfo pTimeInfo)
        {
                _pOdometricLocalizer = pOdometricLocalizer;

                _pRobotParams = pRobotParams;
                _pTimeInfo = pTimeInfo;
                
                IsInitialized = false;

                VelocityPParam = 0.0f;
                VelocityIParam = 0.0f;
                
                TurnPParam = 0.0f;
                TurnIParam = 0.0f;

                CommandedVelocity = 0.0f;
                CommandedAngularVelocity = 0.0f;
        }
        
        private long getTimeMillisecs(){
        	return System.currentTimeMillis();
        }
        
        private void Initialize(float velocityPParam, float velocityIParam, float turnPParam, float turnIParam, float commandTimeout)
        {
                VelocityPParam = velocityPParam;
                VelocityIParam = velocityIParam;

                TurnPParam = turnPParam;
                TurnIParam = turnIParam;
                
                // Avoiding runaway integral error contributions
                _MaxVelocityErrorIntegral = 1 / VelocityIParam;
                _MaxTurnErrorIntegral = 1 / TurnIParam;
                
                _CommandTimeout = commandTimeout;
                _MillisecsLastCommand = getTimeMillisecs();

                IsInitialized = true;
        }
        
        void CommandVelocity(float commandedVelocity, float commandedAngularVelocity)
        {
                CommandedVelocity = commandedVelocity;
                CommandedAngularVelocity = commandedAngularVelocity;
                _MillisecsLastCommand = getTimeMillisecs();
        }
        
        public void Update(boolean batteryVoltageIsTooLow)
        {
                if (batteryVoltageIsTooLow)
                {
                        // we need to stop the motors and stop accumulating errors
                        Reset();
                        return;
                }

                // How long has it been since we received the last command
                float secondsSinceLastCommand = (getTimeMillisecs() - _MillisecsLastCommand) / 1000.0f;
                if (secondsSinceLastCommand > _CommandTimeout)
                {
                        // we need to stop the motors and stop accumulating errors
                        Reset();
                        return;
                }

                float angularVelocityOffset = (float) (0.5 * CommandedAngularVelocity * _pRobotParams.TrackWidth);
                
                float expectedLeftSpeed = CommandedVelocity - angularVelocityOffset;
                float expectedRightSpeed = CommandedVelocity + angularVelocityOffset;

                LeftError = (float) (expectedLeftSpeed - _pOdometricLocalizer.VLeft);
                RightError = (float) (expectedRightSpeed - _pOdometricLocalizer.VRight);
                TurnError = LeftError - RightError; // if > 0 then we need to steer more to the left (and vice versa)

                _LeftErrorIntegral += LeftError;
                _RightErrorIntegral += RightError;
                _TurnErrorIntegral += TurnError;

                // Avoiding runaway integral error contributions
                _LeftErrorIntegral = constrain(_LeftErrorIntegral, -_MaxVelocityErrorIntegral, +_MaxVelocityErrorIntegral);
                _RightErrorIntegral = constrain(_RightErrorIntegral, -_MaxVelocityErrorIntegral, +_MaxVelocityErrorIntegral);
                _TurnErrorIntegral = constrain(_TurnErrorIntegral, -_MaxTurnErrorIntegral, +_MaxTurnErrorIntegral);

                //float leftErrorDifferential = (LeftError - _LastLeftError);
                //float rightErrorDifferential = (RightError - _LastRightError);
                
                NormalizedLeftCV = VelocityPParam * LeftError + VelocityIParam * _LeftErrorIntegral
                                   + (TurnPParam * TurnError + TurnIParam * _TurnErrorIntegral);
                NormalizedLeftCV = constrain(NormalizedLeftCV, -1, +1);

                NormalizedRightCV = VelocityPParam * RightError + VelocityIParam * _RightErrorIntegral
                                    - (TurnPParam * TurnError + TurnIParam * _TurnErrorIntegral);
                NormalizedRightCV = constrain(NormalizedRightCV, -1, +1);
                
                //_LastLeftError = LeftError;
                //_LastRightError = RightError;
        }
        
        float constrain(float x,float lo, float hi) {
        	  double t = (x-lo) / (hi-lo);
        	  return (float) (lo + (hi-lo) * (t-Math.floor(t)));
        	}

};
