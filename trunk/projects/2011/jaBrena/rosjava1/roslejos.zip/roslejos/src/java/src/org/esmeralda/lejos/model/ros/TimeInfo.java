package org.esmeralda.lejos.model.ros;

import java.util.Calendar;

public class TimeInfo{
                public long LastUpdateMicrosecs;              
                public long LastUpdateMillisecs;
                public long CurrentMicrosecs;
                //unsigned long CurrentMillisecs;
                public long MicrosecsSinceLastUpdate;
                //unsigned long MillisecsSinceLastUpdate;
                public float SecondsSinceLastUpdate;

                public TimeInfo(){
                		//Calendar now = Calendar.getInstance();
                		//now.getTimeInMillis();
                	
                        CurrentMicrosecs = getTimeMicrosecs();
                        LastUpdateMicrosecs = CurrentMicrosecs;
                        MicrosecsSinceLastUpdate = 0;
                        SecondsSinceLastUpdate = 0.0f;
                }

                private long getTimeMicrosecs(){
                	return System.currentTimeMillis() * 1000;
                }
                
                private long getTimeMillisecs(){
                	return System.currentTimeMillis();
                }
                
                public void Update(){
                        CurrentMicrosecs = getTimeMicrosecs();
                        LastUpdateMillisecs = getTimeMillisecs();
                        // this rolls over after roughly 70 minutes at the max ulong value 4,294,967,295
                        MicrosecsSinceLastUpdate = CurrentMicrosecs - LastUpdateMicrosecs;
                        if (MicrosecsSinceLastUpdate < 0){
                                // rollover occured
                        		long limit = 4294967295l;
                                MicrosecsSinceLastUpdate = limit - LastUpdateMicrosecs + CurrentMicrosecs;
                        }
                        LastUpdateMicrosecs = CurrentMicrosecs;
                        SecondsSinceLastUpdate = MicrosecsSinceLastUpdate / 1000000.0f;
                }
};
