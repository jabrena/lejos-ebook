import ros.*;
import ros.communication.*;
import ros.pkg.roslejos.srv.*;

public class RosLejosClient{
    public static void main(String args[]) 
    throws InterruptedException, RosException, NumberFormatException {
        final Ros ros = Ros.getInstance();
		
		if (args.length != 3) {
			ros.logInfo("usage: Command, Parameter 1, Parameter 2");
			System.exit(1); 
		}
		
        ros.init("RosLejosClient");        
        NodeHandle n = ros.createNodeHandle();        
		
		ServiceClient<DriveDeadReconingRobot.Request,DriveDeadReconingRobot.Response,DriveDeadReconingRobot>client= 
		n.serviceClient("roslejos_base" , new DriveDeadReconingRobot(), false);
        
		DriveDeadReconingRobot.Request rq = new DriveDeadReconingRobot.Request();
		
		rq.command = Long.parseLong(args[0]); 
		rq.parameter1 = Float.parseFloat(args[1]); 
		rq.parameter2 = Long.parseLong(args[2]); 
		
		try {
			DriveDeadReconingRobot.Response resp = client.call(rq); 
			ros.logInfo("Status: " + resp.status); 
		}
		catch (RosException e) {
			ros.logError("Failed to call service RosLejos"); 
			System.exit(1); 
		}
		
		//If don't call n.shutdown, client thread will hang until ctrl+c
		n.shutdown(); 
    }
}
