package org.esmeralda.lejos.model;

public class DataExchange {
	public float distance = 0;
	public int speed = 0;
	public float angle = 0;
	public int angularSpeed = 0;
}
