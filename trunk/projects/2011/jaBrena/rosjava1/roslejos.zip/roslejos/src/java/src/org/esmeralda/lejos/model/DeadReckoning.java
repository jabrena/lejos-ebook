package org.esmeralda.lejos.model;

public class DeadReckoning extends Robot{
	
	public DeadReckoning(float _wheelDiameter, float _trackWidth){
		super(_wheelDiameter,_trackWidth);
	}
	
	public void drive(float distance, int speed){
		//The speed in wheel diameter units per second.
		this.getPilot().setMoveSpeed(speed);
		this.getPilot().travel(distance);
	}
	
	public void turn(float angle, int angularSpeed){
		//The speed in degree per second.
		this.getPilot().setTurnSpeed(angularSpeed);
		this.getPilot().rotate(angle);	
	}

}
