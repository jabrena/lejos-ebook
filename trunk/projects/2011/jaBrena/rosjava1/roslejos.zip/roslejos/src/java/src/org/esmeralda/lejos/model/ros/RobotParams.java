package org.esmeralda.lejos.model.ros;

public class RobotParams
{
	private final float PI = 3.14159265f;

                public boolean IsInitialized;
                public double WheelDiameter;
                public double TrackWidth;
                public double CountsPerRevolution;
                public double DistancePerCount;
                public double RadiansPerCount;


                public RobotParams()
                {
                        IsInitialized = false;
                }

                // initializes robot params wheel diameter [m], trackwidth [m], ticks per revolution
                public void Initialize(double wheelDiameter, double trackWidth, int countsPerRevolution)
                {
                        WheelDiameter = wheelDiameter;
                        TrackWidth = trackWidth;
                        CountsPerRevolution = countsPerRevolution;

                        DistancePerCount = (PI * wheelDiameter) / (double)countsPerRevolution;
                        RadiansPerCount = DistancePerCount / trackWidth;

                        IsInitialized = true;
                }
};

