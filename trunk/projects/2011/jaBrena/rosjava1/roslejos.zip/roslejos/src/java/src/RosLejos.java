import ros.*;
import ros.communication.*;
//import ros.ServiceClient;

//ROS Services
import ros.pkg.roslejos.srv.*;

//LeJOS
import org.esmeralda.lejos.comms.USBConnector;
import org.esmeralda.lejos.model.DeadReckoning;

public class RosLejos {
	
	private static Ros ros;
	private static NodeHandle n;
	
	private static USBConnector bm;
	private static DeadReckoning dr;

	private static void initRos() {

    	ros = Ros.getInstance();

		if(!Ros.getInstance().isInitialized()) {
	    	ros.init("RosLejos");
		}
		n = ros.createNodeHandle();

	}
	
	private static void initNXT(){
		String BRICK_NAME = "ROSBRICK1";
		String BRICK_ADDRESS = "0016530936DF";
		bm = new USBConnector(BRICK_NAME,BRICK_ADDRESS);
		bm.connectWithFirstBrick();
		
    	float wheelDiameter = 5.0f;
    	float trackWidth = 16.0f;
		dr = new DeadReckoning(wheelDiameter,trackWidth);
	}
	
    private static void closeNXT(){
		  //Close the USB Connection
		  bm.close();
    }
	
    private static void initServices(){
    	try{
            ServiceServer.Callback<DriveDeadReconingRobot.Request,DriveDeadReconingRobot.Response> scb = 
                new ServiceServer.Callback<DriveDeadReconingRobot.Request,DriveDeadReconingRobot.Response>() {
                    public DriveDeadReconingRobot.Response call(DriveDeadReconingRobot.Request request) {
                    	DriveDeadReconingRobot.Response res = new DriveDeadReconingRobot.Response();
                        
                    	int cmd = (int) request.command;
                    	float parameter1 = request.parameter1;
                    	int parameter2 = (int) request.parameter2;
                    	
                    	//Integration with NXT Brick
                    	if(cmd == request.CMD_DRIVE){
                    		dr.drive(parameter1,parameter2);
                    	}else if(cmd == request.CMD_TURN){
                    		dr.turn(parameter1,parameter2);
                    	}
                    	
                    	res.status = "OK";
                        ros.logInfo("request: P1=" + request.parameter1 + ", P2=" + request.parameter2);
                        ros.logInfo("sending back response: " + res.status); 
                        
                        return res;
                    }
                };            
                
                ServiceServer<DriveDeadReconingRobot.Request,DriveDeadReconingRobot.Response,DriveDeadReconingRobot> srv = 
                n.advertiseService("roslejos_base", new DriveDeadReconingRobot(), scb);
                
                ros.logInfo("Ready to process commands for NXT Brick."); 
                
                n.spin();
    	}catch(RosException e){
    		
    	}

    }
    
    public static void main(String args[]) throws InterruptedException, RosException {
    	
    	initNXT();
    	initRos();
    	initServices();
            
	}

}
