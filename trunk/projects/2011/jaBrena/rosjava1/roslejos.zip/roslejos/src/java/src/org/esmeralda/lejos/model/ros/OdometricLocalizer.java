package org.esmeralda.lejos.model.ros;




//http://www.ridgesoft.com/articles/trackingposition/TrackingPosition.pdf

public class OdometricLocalizer{

	float PI = 3.14159265f;
	float TwoPI = 6.28318531f;

        RobotParams _pRobotParams;
        TimeInfo _pTimeInfo;
        double _DistancePerCount;
        double _RadiansPerCount;

        long _LeftEncoderCounts;
        long _PreviousLeftEncoderCounts;

        long _RightEncoderCounts;
        long _PreviousRightEncoderCounts;


        public OdometricLocalizer(RobotParams pRobotParams, TimeInfo pTimeInfo){
                _pRobotParams = pRobotParams;
                _pTimeInfo = pTimeInfo;
        }

        public double X;  // x coord in global frame
        public double Y;  // y coord in global frame
        public double Heading;  // heading (radians) in the global frame. The value lies in (-PI, PI]
        
        public double VLeft;   // left motor speed
        public double VRight;  // right motor speed
        public double V;  // forward speed
        public double Omega;  // angular speed (radians per sec)

        // Must be periodically called
        public void Update(long leftEncoderCounts, long rightEncoderCounts){
                long deltaLeft = leftEncoderCounts - _PreviousLeftEncoderCounts;
                long deltaRight = rightEncoderCounts - _PreviousRightEncoderCounts;

                VLeft = deltaLeft * _pRobotParams.DistancePerCount / _pTimeInfo.SecondsSinceLastUpdate;
                VRight = deltaRight * _pRobotParams.DistancePerCount / _pTimeInfo.SecondsSinceLastUpdate;

                double deltaDistance = 0.5f * (double)(deltaLeft + deltaRight) * _pRobotParams.DistancePerCount;
                double deltaX = deltaDistance * (double)Math.cos(Heading);
                double deltaY = deltaDistance * (double)Math.sin(Heading);

                double deltaHeading = (double)(deltaRight - deltaLeft) * _pRobotParams.RadiansPerCount;

                X += deltaX;
                Y += deltaY;
                Heading += deltaHeading;
                // limit heading to -Pi <= heading < Pi
                if (Heading > PI)
                {
                        Heading -= TwoPI;
                }
                else
                {
                        if (Heading <= -PI)
                        {
                                Heading += TwoPI;
                        }
                }
                
                V = deltaDistance / _pTimeInfo.SecondsSinceLastUpdate;
                Omega = deltaHeading / _pTimeInfo.SecondsSinceLastUpdate;

                _PreviousLeftEncoderCounts = leftEncoderCounts;
                _PreviousRightEncoderCounts = rightEncoderCounts;
        }
};
