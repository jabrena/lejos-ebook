package org.esmeralda.lejos.comms;
import java.io.IOException;

import lejos.nxt.*;
import lejos.nxt.remote.NXTCommand;
import lejos.nxt.remote.RemoteMotor;
import lejos.pc.comm.*;
import lejos.robotics.navigation.TachoPilot;


public class USBConnector {

	//Connection
	private String BrickName = "";
	private String BrickAddress = "";
	private NXTInfo[] nxtInfo = null;
    private NXTComm nxtComm = null;
    private NXTConnector conn = null;
	
	public USBConnector(String _BrickName, String _BrickAddress){
		BrickName = _BrickName;
		BrickAddress = _BrickAddress;
		NXTInfo[] nxtInfo = new NXTInfo[1];
		nxtInfo[0] = new NXTInfo(0, BrickName,BrickAddress);
	}
	
	public boolean connectWithFirstBrick(){
		conn = new NXTConnector();
		boolean connectionStatus = false;
		System.out.println();
		
		connectionStatus = conn.connectTo(BrickName, NXTComm.LCP);
		
		if(!connectionStatus) {
	        System.err.println("Conexión Fallida");
		}else{
		      NXTCommand.getSingleton().setNXTComm(conn.getNXTComm());
		}
		
		return connectionStatus;
	}
	
	public void close(){
	    try {
			conn.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
